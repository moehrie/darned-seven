

/**
 * @author 
 * @version 
 */
public class Spieler
{
    // Bezugsobjekte

    // Attribute
    private int Einsatz;
    private int Pot;
    private int Vermögen;

    // Konstruktor
    
    
    public Spieler()
    {
        Einsatz = 0;
        Pot = 0;
        Vermögen = 1000;
    }

    // Dienste
    public void Einsatz ()
    {
     Einsatz
    }
    
}
